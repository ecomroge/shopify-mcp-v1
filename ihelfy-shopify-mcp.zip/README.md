# iHELFY Shopify MCP — Custom Server

MCP server con tools completos de Shopify incluyendo edición de temas.

## Variables de entorno requeridas en Railway

| Variable | Descripción |
|---|---|
| `SHOPIFY_STORE` | Tu store name, ej: `ihelfy` |
| `SHOPIFY_ACCESS_TOKEN` | Admin API Access Token |
| `TRANSPORT` | `http` (default) |
| `PORT` | `3000` (default) |

## Tools disponibles

### Productos
- `shopify_list_products` — Listar productos
- `shopify_get_product` — Obtener producto por ID
- `shopify_update_product` — Actualizar producto (title, body_html, tags, etc.)
- `shopify_create_product` — Crear producto

### Temas ⭐ NUEVO
- `shopify_list_themes` — Ver todos los temas
- `shopify_get_theme_files` — Ver archivos de un tema
- `shopify_get_theme_file` — Leer contenido de un archivo Liquid/CSS/JS
- `shopify_update_theme_file` — **Editar archivo del tema**
- `shopify_get_section_data` — Ver JSON de secciones de un template
- `shopify_update_section_data` — **Editar secciones del template**

### Metafields ⭐ NUEVO
- `shopify_get_product_metafields` — Ver metafields de un producto
- `shopify_set_product_metafield` — Crear/actualizar metafield

### Pedidos
- `shopify_list_orders` — Listar pedidos
- `shopify_get_order` — Obtener pedido por ID

### Clientes
- `shopify_list_customers` — Listar clientes
- `shopify_search_customers` — Buscar clientes

### Colecciones
- `shopify_list_collections` — Ver colecciones
